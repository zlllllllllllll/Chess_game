//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameClient.rc
//
#define IDR_MAINFRAME                   128
#define IDR_WAVE1                       146
#define IDB_VIEW_BACK                   147
#define IDC_CARD_CUR                    147
#define IDB_CARD_BACK_H                 150
#define IDB_CARD_BACK_V                 151
#define IDB_CARD_HEAP_DOUBLE_H          152
#define IDB_CARD_HEAP_DOUBLE_V          153
#define IDB_CARD_HEAP_SINGLE_H          154
#define IDB_CARD_HEAP_SINGLE_V          155
#define IDB_CARD_TABLE_BOTTOM           156
#define IDB_CARD_TABLE_LEFT             157
#define IDB_CARD_TABLE_RIGHT            158
#define IDB_CARD_TABLE_TOP              159
#define IDB_CARD_USER_BOTTOM            160
#define IDB_CARD_USER_LEFT              161
#define IDB_CARD_USER_RIGHT             162
#define IDB_CARD_USER_TOP               163
#define IDB_BT_START                    164
#define IDB_HUANG_ZHUANG                168
#define IDB_ACTION_BACK                 169
#define IDB_USER_ACTION                 170
#define IDB_USER_FLAG                   171
#define IDD_OPTION                      175
#define IDB_WAIT_TIP                    178
#define IDB_BT_LISTEN                   179
#define IDB_GAME_SCORE                  180
#define IDB_ACTION_EXPLAIN              184
#define IDB_LISTEN_FLAG_V               187
#define IDB_LISTEN_FLAG_H               188
#define IDB_BITMAP1                     191
#define IDB_SELECT                      191
#define IDB_BT_SCORE_CLOSE              193
#define IDB_BITMAP2                     194
#define IDB_GAME_SCORE_FLAG             194
#define IDB_BITMAP3                     195
#define IDB_TRUSTEE                     195
#define IDB_BITMAP4                     196
#define IDB_VIEW_CENTER                 196
#define IDD_CARD_EXTRACTOR              197
#define IDB_BT_START_TRUSTEE            206
#define IDB_BT_STOP_TRUSTEE             207
#define IDB_BT_MAI_CANCEL               208
#define IDB_BT_MAI_DINGDI               209
#define IDB_BT_MAIDI                    210
#define IDB_BITMAP5                     211
#define IDB_CARD_USER_DISABLE           211
#define IDB_ANIM_SAIZI                  212
#define IDR_WAVE2                       213
#define IDB_BITMAP6                     214
#define IDB_DINGMAI_FRAME               214
#define IDB_NUMBER                      215
#define IDB_DINGMAI                     216
#define IDB_BITMAP7                     217
#define IDB_CS_BACK                     217
#define IDB_CONTROL                     218
#define IDB_BT_QUXIAO                   219
#define IDB_BT_CHI_SHANG                220
#define IDB_BT_CHI_XIA                  221
#define IDB_BT_CHI_ZHONG                222
#define IDB_BT_GANG                     223
#define IDB_BT_HU                       224
#define IDB_BT_PENG                     225
#define IDB_CS_FLAG                     226
#define IDB_BT_DI_CANCEL                228
#define IDB_TIME_NUMBER                 229
#define IDB_TIME_BACK                   230
#define IDB_BITMAP8                     231
#define IDB_CARD_BACK                   231
#define IDB_BITMAP9                     232
#define IDB_READY                       232
#define IDB_BITMAP10                    233
#define IDB_CARD_WAVE_BOTTOM            233
#define IDB_BITMAP11                    234
#define IDB_SCORE_DRAW                  234
#define IDB_BITMAP12                    235
#define IDB_SCORE_WIN                   235
#define IDB_BITMAP13                    236
#define IDB_TIP_SINGLE                  236
#define IDB_CONTROL_TOP                 237
#define IDB_CONTROL_MID                 238
#define IDB_BITMAP14                    239
#define IDB_CONTROL_BOTTOM              239
#define IDC_ENABLE_LOOKON               1000
#define IDC_ENABLE_SOUND                1002
#define IDC_COMBOX_MANDERIN             1003
#define IDC_CHINESE_VOICE               1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        240
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
